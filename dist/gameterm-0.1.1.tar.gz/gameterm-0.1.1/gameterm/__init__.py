"""gameterm is designed to be a flexible terminal,
not hosting a system shell, but an internal shell of
a program, running on the pygame library. Highly customizable,
and simple to use.
"""

__author__ = 'Michael Gill <michael.78912.8@gmail.com>'
__version__ = '0.0 Pre-Alpha'
